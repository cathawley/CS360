package com.zybooks.eventapp_hawley;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextName, editTextPassword;
    private Button buttonLogin, buttonCreateAccount;
    private LoginDatabase loginDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize the widgets on the Login screen
        editTextName = findViewById(R.id.editTextName);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        //Create an intent to send a successful login to the main activity
        Intent intent = new Intent(this, MainActivity.class);
        //Initialize the repository to use its methods
        UserRepository userRepository = new UserRepository(this);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            // Checks the contents of the EditTexts against the existing logins in the database
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String password = editTextPassword.getText().toString();

                if (userRepository.verifyLogin(name, password)) {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    startActivity(intent);  // Success -> main activity
                }
                else {
                    Toast.makeText(LoginActivity.this, "Incorrect Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonCreateAccount.setOnClickListener(new View.OnClickListener() {
            // Adds the EditText inputs to the Login database
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String password = editTextPassword.getText().toString();

                if (userRepository.checkNameAvail(name)) {
                    Toast.makeText(LoginActivity.this, "Username Taken", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Creating User...", Toast.LENGTH_SHORT).show();
                    userRepository.addUser(name, password);
                    Toast.makeText(LoginActivity.this, "You May Log In Now", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}