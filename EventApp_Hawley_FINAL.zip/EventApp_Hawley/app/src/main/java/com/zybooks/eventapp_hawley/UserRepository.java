package com.zybooks.eventapp_hawley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepository {
    private final LoginDatabase loginDatabase;
    private SQLiteDatabase database;
    public UserRepository(Context context) {
        loginDatabase = new LoginDatabase(context);
    }

    public void addUser(String name, String password) {  //assigns text from EditTexts to the login.db table
        database = loginDatabase.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginDatabase.COL_NAME, name);
        values.put(LoginDatabase.COL_PASS, password);

        database.insert(LoginDatabase.TABLE, null, values);
        database.close();
    }

    public boolean verifyLogin(String name, String password) {
        database = loginDatabase.getReadableDatabase();
        String[] columns = {LoginDatabase.COL_ID};
        String selection = LoginDatabase.COL_NAME + " = ? AND " + LoginDatabase.COL_PASS + " = ?";
        String[] selectionArgs = {name, password};  // uses the name and password from the EditText fields as search query

        Cursor cursor = database.query(LoginDatabase.TABLE, columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            database.close();
            return true;  // Returns true because the name and password match a name and password in the database
        } else {
            database.close();
            return false;
        }
    }
    public boolean checkNameAvail(String name) {  // Similar to verifying login, this method ensures one username doesn't have multiple working passwords
        database = loginDatabase.getReadableDatabase();
        String[] columns = {LoginDatabase.COL_ID};
        String selection = LoginDatabase.COL_NAME + " = ?";
        String[] selectionArgs = {name};

        Cursor cursor = database.query(LoginDatabase.TABLE, columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            database.close();
            return true;
        } else {
            cursor.close();
            database.close();
            return false;
        }
    }
}
