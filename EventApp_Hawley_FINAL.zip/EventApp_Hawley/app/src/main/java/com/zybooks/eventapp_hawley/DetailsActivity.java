package com.zybooks.eventapp_hawley;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();  //Gets the intent from MainActivity

        // Initializing the screen's widgets
        final EditText phoneNumber = (EditText) findViewById(R.id.phoneNumber);
        final EditText eventTitle = (EditText) findViewById(R.id.eventTitle);
        final EditText eventDate = (EditText) findViewById(R.id.eventDate);
        final EditText eventTime = (EditText) findViewById(R.id.eventTime);
        final EditText eventNote = (EditText) findViewById(R.id.eventNote);
        final CheckBox eventSMS = (CheckBox) findViewById(R.id.checkboxSMS);
        TextView textViewPhoneNumber = (TextView)findViewById(R.id.textViewPhoneNumber);

        Button buttonApply = findViewById(R.id.buttonApply);
        Button buttonDelete = findViewById(R.id.buttonDelete);

        EventRepository eventRepository = new EventRepository(this);

        // Getting the details from the intent
        String title = intent.getStringExtra("title");
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");
        String note = intent.getStringExtra("note");
        String number = intent.getStringExtra("number");
        int sms = intent.getIntExtra("sms", 0);
        int id = intent.getIntExtra("id", -1);

        if (id != -1) { // Populate the details page if editing an event
            eventTitle.setText(title);
            eventDate.setText(date);
            eventTime.setText(time);
            eventNote.setText(note);
            phoneNumber.setText(number);
            buttonDelete.setVisibility(View.VISIBLE);
            if (sms == 1) {
                eventSMS.setChecked(true);
                textViewPhoneNumber.setVisibility(View.VISIBLE);
                phoneNumber.setVisibility(View.VISIBLE);
            }
        }

        eventSMS.setOnClickListener(new View.OnClickListener() { // Requests permission if user wants SMS notification, makes the phone number field visible
            public void onClick(View view) {
                textPermission(Manifest.permission.SEND_SMS, 1);
                textViewPhoneNumber.setVisibility(View.VISIBLE);
                phoneNumber.setVisibility(View.VISIBLE);
            }
        });

        buttonApply.setOnClickListener(new View.OnClickListener() {  // starts method if Apply Changes button is clicked
            public void onClick(View view) {
                // Get the inputs from the EditText fields, checks if sms checkbox is checked
                String title = eventTitle.getText().toString();
                String date = eventDate.getText().toString();
                String time = eventTime.getText().toString();
                String note = eventNote.getText().toString();
                String number = phoneNumber.getText().toString();
                int sms = (eventSMS.isChecked() ? 1:0);


                if (number.isEmpty()){  // Prevents bug when phone number field is null
                    number= "none";
                }

                if (id != -1) {  //If editing an existing event
                    eventRepository.updateEvent(title, date, time, note, number, sms, id);
                    Toast.makeText(DetailsActivity.this, "Changes saved", Toast.LENGTH_LONG).show();
                } else {  // Creating a new event
                    eventRepository.addEvent(title, date, time, note, number, sms);
                    Toast.makeText(DetailsActivity.this, "Event added", Toast.LENGTH_LONG).show();
                }
                startActivity(new Intent(DetailsActivity.this, MainActivity.class));  // Returns to Main Activity
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {  // Checks for Delete button to be clicked
            public void onClick(View view) {
                eventRepository.deleteEvent(id);  // Deletes current event
                Toast.makeText(DetailsActivity.this, "Event deleted",  Toast.LENGTH_SHORT).show();
                startActivity(new Intent(DetailsActivity.this, MainActivity.class)); // Returns to Main Activity
            }
        });

    }
    public void textPermission(String permission, int requestCode) {
        // Requests permission to send SMS if not granted, occurs when user requests notification
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(DetailsActivity.this, new String[] {android.Manifest.permission.SEND_SMS}, requestCode);
        }
    }

}