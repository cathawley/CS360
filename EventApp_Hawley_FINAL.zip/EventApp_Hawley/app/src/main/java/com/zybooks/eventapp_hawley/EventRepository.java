package com.zybooks.eventapp_hawley;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class EventRepository {
    private final EventDatabase eventDatabase;
    private SQLiteDatabase database;

    public EventRepository(Context context) {
        eventDatabase = new EventDatabase(context);
    }

    public void addEvent(String title, String date, String time, String note, String number, int sms) {
        database = eventDatabase.getWritableDatabase();  // Allows the database to be written to

        // assigns the event's details to values
        ContentValues values = new ContentValues();
        values.put(EventDatabase.COL_TITLE, title);
        values.put(EventDatabase.COL_DATE, date);
        values.put(EventDatabase.COL_TIME, time);
        values.put(EventDatabase.COL_NOTE, note);
        values.put(EventDatabase.COL_NUM, number);
        values.put(EventDatabase.COL_SMS, sms);

        long newId = DatabaseUtils.longForQuery(database, "select max(_id) from " + EventDatabase.TABLE, null) + 1;
        values.put(EventDatabase.COL_ID, newId);  // Prevents bug where deleting an earlier event broke the gridview

        //inserts the values into the events database
        database.insert(EventDatabase.TABLE, null, values);
        database.close();
    }

    public void updateEvent(String title, String date, String time, String note, String number, int sms, int id) {
        database = eventDatabase.getWritableDatabase();

        //assigns the event's new details to values
        ContentValues values = new ContentValues();
        values.put(EventDatabase.COL_TITLE, title);
        values.put(EventDatabase.COL_DATE, date);
        values.put(EventDatabase.COL_TIME, time);
        values.put(EventDatabase.COL_NOTE, note);
        values.put(EventDatabase.COL_NUM, number);
        values.put(EventDatabase.COL_SMS, sms);

        //changes the values of the chosen event
        database.update(EventDatabase.TABLE, values, "_id = ?", new String[]{String.valueOf(id+1)});
        database.close();
    }

    public void deleteEvent(int id) {
        database = eventDatabase.getWritableDatabase();
        ++id;
        database.delete(EventDatabase.TABLE, "_id = ?", new String[]{String.valueOf(id)});
        // de-increments id for events added after the deleted event, allowing new events to be clicked in Main Activity
        database.execSQL("update " + EventDatabase.TABLE + " set _id = _id-1 where _id > ?", new String[]{String.valueOf(id)});

    }
    @SuppressLint("Range")
    public ArrayList<String> getEvents() {  // Returns data for the main activity, all events but only the title, date, and time
        database = eventDatabase.getReadableDatabase();
        ArrayList<String> eventList = new ArrayList<>();

        Cursor cursor = database.rawQuery("select * from events", null);  // cursor will traverse every row
        cursor.moveToFirst();

        if (cursor != null) {
            while(cursor.isAfterLast() == false){
                String title;
                String date;
                String time;
                title = cursor.getString(cursor.getColumnIndex("title"));
                date = cursor.getString(cursor.getColumnIndex("date"));
                time = cursor.getString(cursor.getColumnIndex("time"));
                eventList.add(title + "\n" + date + "\n" + time);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return eventList;
    }

    @SuppressLint("Range")
    public ArrayList<String> getDetail(int id) {  // Returns data for DetailsActivity, only one event but all of its information
        database = eventDatabase.getReadableDatabase();
        ArrayList<String> listDetails = new ArrayList<>();
        String[] selectionArgs = {String.valueOf(id)};

        Cursor cursor = database.rawQuery("select * from events where _id = ?", selectionArgs);
        cursor.moveToFirst();

        if (cursor != null) {
            //Gets one event's details from the database, adds it to an ArrayList
            listDetails.add(cursor.getString(cursor.getColumnIndex("title")));
            listDetails.add(cursor.getString(cursor.getColumnIndex("date")));
            listDetails.add(cursor.getString(cursor.getColumnIndex("time")));
            listDetails.add(cursor.getString(cursor.getColumnIndex("note")));
            listDetails.add(cursor.getString(cursor.getColumnIndex("number")));
            listDetails.add(String.valueOf(cursor.getInt(cursor.getColumnIndex("sms"))));

            cursor.close();
            database.close();
        }
        return listDetails;
    }

    @SuppressLint("Range")
    public ArrayList<String> checkDates(String date){  // Checks all dates in the database for today's date
        database = eventDatabase.getReadableDatabase();
        ArrayList<String> todayEvents = new ArrayList<>();
        String[] selectionArgs = {date};

        Cursor cursor = database.rawQuery("select * from events where date = ?", selectionArgs);  // cursor will traverse every row
        cursor.moveToFirst();

        if (cursor != null) {
            while(cursor.isAfterLast() == false){
                String id = cursor.getString(cursor.getColumnIndex("_id"));
                todayEvents.add(id);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return todayEvents;
    }

}