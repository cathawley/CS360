package com.zybooks.eventapp_hawley;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    EventRepository eventRepository = new EventRepository(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        //Initialize onCreate variables, populating the MainActivity screen with the gridview, and its events
        GridView eventGrid = (GridView) findViewById(R.id.gridviewEvents);
        ArrayList<String> eventList = eventRepository.getEvents();
        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), eventList);

        //Initializing text message notification service
        SmsManager smsManager = SmsManager.getDefault();

        //Initializing calendar for notifications
        Calendar calendar = Calendar.getInstance();
        int todayMonth = calendar.get(Calendar.MONTH);
        int todayDayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        String todayDate = (String.valueOf(todayMonth + 1) + "-" + String.valueOf(todayDayOfMonth));
        ArrayList<String> todayEvents = eventRepository.checkDates(todayDate);

        //Initializing the timer
        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                for (int i=0; i < todayEvents.size(); ++i){
                    ArrayList<String> todayDetails = eventRepository.getDetail(Integer.parseInt(todayEvents.get(i)));  // gets the details from all today's events
                    String title = todayDetails.get(0);
                    String date = todayDetails.get(1);
                    String time = todayDetails.get(2);
                    String phNumber = todayDetails.get(4);
                    int sms = Integer.parseInt(todayDetails.get(5));
                    String msg = "Upcoming event:" + title + "is scheduled for " + date + " at " + time + ".";
                    if (sms == 1) {
                        smsManager.sendTextMessage(phNumber, null, msg, null, null);
                    } else{
                        return;
                    }
                }
            }
        };

        timer.schedule(task, calendar.getTime(), 24*60*60*1000);  // Runs the SMS task daily (24 hours)


        class ItemClickListener implements AdapterView.OnItemClickListener{
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Allows for editing/viewing an event's details by clicking on it
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                ArrayList<String> eventDetails = eventRepository.getDetail((i+1));
                String smsString = eventDetails.get(5);  // Special handling for the integer


                // Sends the details over as an intent extra
                intent.putExtra("title", eventDetails.get(0));
                intent.putExtra("date", eventDetails.get(1));
                intent.putExtra("time", eventDetails.get(2));
                intent.putExtra("note", eventDetails.get(3));
                intent.putExtra("number", eventDetails.get(4));
                intent.putExtra("sms", Integer.parseInt(smsString));
                intent.putExtra("id", i);

                startActivity(intent);  //Starts DetailsActivity
            }
        }

        eventGrid.setAdapter(adapter);  // Fills the grid with the events
        eventGrid.setOnItemClickListener(new ItemClickListener());  // Allows events to be clicked

        FloatingActionButton buttonAdd = findViewById(R.id.floatingActionNew);
        buttonAdd.setOnClickListener(new View.OnClickListener() {  // Allows the user to use the floating action button to add new events
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, DetailsActivity.class));
            }
        });
    }

}