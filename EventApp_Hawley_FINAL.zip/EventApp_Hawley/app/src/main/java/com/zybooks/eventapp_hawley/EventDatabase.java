package com.zybooks.eventapp_hawley;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class EventDatabase extends SQLiteOpenHelper {

    public static final String dbName = "Event.db";

    public EventDatabase(@Nullable Context context) {
        super(context, "Event.db", null, 1);
    }

    public static final String TABLE = "events";
    public static final String COL_ID = "_id";
    public static final String COL_TITLE = "title";
    public static final String COL_DATE = "date";
    public static final String COL_TIME = "time";
    public static final String COL_NOTE = "note";
    public static final String COL_NUM = "number";
    public static final String COL_SMS = "sms";

    public static final String COL_TEMPID = "tempid";



    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE + "(" + COL_ID + " integer primary key autoincrement, " + COL_TITLE + " text," + COL_DATE + " text," + COL_TIME + " text," + COL_NOTE + " text," + COL_NUM + " text," + COL_SMS + " integer," + COL_TEMPID + " text" + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);

    }

}
